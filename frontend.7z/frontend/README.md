# gen_ai sql script generator

# step 1: Install streamlit
## pip install streamlit

# step 2: To run the streamlit python script 
## streamlit run query_genrate.py
